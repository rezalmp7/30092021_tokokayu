# Better Rating
jQuery Plugin
> Version 1.0.0
## Client Side Dependencies

````
jQuery,
FontAwesome
````


### Demo

[Demo Click Here](https://malithmcr.github.io/Better-Rating/)