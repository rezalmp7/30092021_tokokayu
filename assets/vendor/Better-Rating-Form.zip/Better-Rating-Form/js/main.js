$('#better-rating-form').betterRating({
    wrapper:'#better-rating-list'
});
